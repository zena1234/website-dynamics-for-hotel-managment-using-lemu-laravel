<?php
namespace App\Models;

use App\Services\MergeDataService;
use App\Traits\UseState;
use Illuminate\Database\Eloquent\Model;

class Services extends Model
{
    use UseState;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'name',
        'floor_number',
        'bed_type',
        'category_id',
        'deleted_at',
        'state'
    ];
    protected $hidden = ['deleted_at'];
    public static function getService(){

    }

   public static function storeService($request){
        $data=new Services();
        $data->name=$request->input('service_name');
        $data->service_id=(new MergeDataService)->StoreMergeData($request)->id;
        $data->save();
        return $data;
   }

    
}

