<?php
namespace App\Models;

use App\Constants\MyModel;
use App\Requests\linksRequest;
use App\Requests\NewsRequest;
use App\Services\MergeDataService;
use App\Services\FileService;
use App\Traits\UseState;
use Illuminate\Database\Eloquent\Model;

class News  extends Model
{
    use UseState;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'user_id',
        'category_id',
        'title',
        'summary',
        'body',
        'featured_photo',
        'published_at',
        'unpublished_at',
        'publshed_by',
        'unpublished_by',
        'deleted_at',
        'state'
    ];
    protected $hidden = ['deleted_at'];

    //Relationship
    public function category()
    {
        return $this->belongsTo(MyModel::CATEGORY)->select('id', 'name');
    }

    //Stores

    public static function storeNews($request){
    //    !$valid=(new NewsRequest)->storeValidationRule($request);
       $data['id']=(new MergeDataService)->StoreMergeData($request)->id;
       $data['state']=(new MergeDataService)->StoreMergeData($request)->state;
       $data['user_id']=$request->input('user_id');
       $data['category_id']=$request->input('category_id');
       $data['title']=$request->input('title');
       $data['summary']=$request->input('summary');
       $data['body']=$request->input('body');
       $name=time().$request->file('featured_photo')->getClientOriginalName();
       (new FileService)->store($request,$name,'featured_photo');
       $upload=$data['featured_photo']=$name;
       $data['published_at']=$request->input('published_at');
       $data['unpublished_at']= $request->input('unpublished_at');
       $data['published_by']= $request->input('published_by');
       $data['unpublished_by']= $request->input('unpublished_by');

       $data['deleted_at']= $request->input('deleted_at');
       return News::create($data);

    }
    public static function changeFile($request,$id){
        $name=time().$request->file('featured_photo')->getClientOriginalName();
        $upload=(new FileService)->store($request,$name,'featured_photo');
        $model=News::findOrFail($id); 
        $model->featured_photo=$name;
        $model->save();
        return $model;
    }

    public static function updateNews($request, $id)
    {
        // $valid = (new NewsRequest)->updateValidationRule($request, $id);
        // if (!$valid) return $valid;

        $model = News::findOrFail($id);
        $model->fill($request->all());
        $model->save();

        return $model;
    }

    public static function toggleStatus($id)
    {
        $model = links::findOrFail($id);
        $model->state = $model->state ^ 1;
        $model->save();
        return $model;
    }
}
