<?php
namespace App\Models;

use App\Constants\MyModel;
use App\Requests\RoomRequest;
use App\Services\MergeDataService;
use App\Services\FileService;
use App\Traits\UseState;
use Illuminate\Database\Eloquent\Model;

class Testimony extends Model
{
    use UseState;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
       'id',
       'name',
       'position',
       'quoted_text',
       'featured_photo',
       'state'
    ];
    protected $hidden = ['deleted_at'];

    //Relationship
    public function category()
    {
        return $this->belongsTo(MyModel::CATEGORY)->select('id', 'name');
    }
    //Stores
    public static function storeTestimony($request)
    {
        $valid = (new RoomRequest)->storeValidationRule($request);// I used roomRequest since both room request and testimonial need their name required
        if (!$valid)
             return $valid;
        $data['name']=$request->input('name');
        $data['position']=$request->input('position');
        $data['quoted_text']=$request->input('quoted_text');
        $data['id']=(new MergeDataService)->StoreMergeData($request)->id;
        $data['state']=(new MergeDataService)->StoreMergeData($request)->state;
        $name=time().$request->file('featured_photo')->getClientOriginalName();
        $upload=(new FileService)->store($request,$name,'featured_photo');
        $data['featured_photo']=$name;
        return Testimony::Create( $data);
        
    }

    public static function changeFeaturedPhoto($request,$id){
        $name=time().$request->file('featured_photo')->getClientOriginalName();
        $upload=(new FileService)->store($request,$name,'featured_photo');
        $model=Testimony::findOrFail($id); 
        $model->featured_photo=$name;
        $model->save();
        return $model;
    }

    public static function updateTestimony($request, $id)
    {
        $valid = (new RoomRequest)->updateValidationRule($request, $id);
        if (!$valid) return $valid;
       
        $model = Testimony::findOrFail($id);
        $model->fill($request->all());
        $model->save();

        return $model;
    }

    public static function toggleStatus($id)
    {
        $model = Testimony::findOrFail($id);
        $model->state = $model->state ^ 1;
        $model->save();
        return $model;
    }
}