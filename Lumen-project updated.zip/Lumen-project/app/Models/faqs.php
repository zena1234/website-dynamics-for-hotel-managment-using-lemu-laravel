<?php
namespace App\Models;

use App\Constants\MyModel;
use App\Requests\RoomRequest;
use App\Requests\FAQsRequest;
use App\Services\MergeDataService;
use App\Traits\UseState;
use Illuminate\Database\Eloquent\Model;

class Faqs  extends Model
{
    use UseState;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'question',
        'answer',
        'detailed_answer',
        'deleted_at',
        'state'
    ];
    protected $hidden = ['deleted_at'];

    //Relationship
    public function category()
    {
        return $this->belongsTo(MyModel::CATEGORY)->select('id', 'name');
    }

    //Stores
    public static function storeFAQ($request)
    {
        $valid = (new FAQsRequest)->storeValidationRule($request);
        if (!$valid) return $valid;

        return FAQs::Create(
            (new MergeDataService)->StoreMergeData($request)
                ->all()
        );
    }

    public static function updateFAQ($request, $id)
    {
        $valid = (new FAQsRequest)->updateValidationRule($request, $id);
        if (!$valid) return $valid;

        $model = FAQs::findOrFail($id);
        $model->fill($request->all());
        $model->save();

        return $model;
    }

    public static function toggleStatus($id)
    {
        $model = FAQs::findOrFail($id);
        $model->state = $model->state ^ 1;
        $model->save();
        return $model;
    }
}
