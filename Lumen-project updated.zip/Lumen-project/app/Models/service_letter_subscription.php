<?php
namespace App\Models;

use App\Constants\MyModel;
use App\Requests\FAQsRequest;
use App\Services\MergeDataService;
use App\Traits\UseState;
use Illuminate\Database\Eloquent\Model;

class Service_letter_subscription  extends Model
{
    use UseState;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'email',
        'state'
    ];
    protected $hidden = [];

    //Relationship
    public function category()
    {
        return $this->belongsTo(MyModel::CATEGORY)->select('id', 'name');
    }

    //Stores
    public static function store($request)
    {
        // $valid = (new FAQsRequest)->storeValidationRule($request);
        // if (!$valid) return $valid;

        return Service_letter_subscription::Create(
            (new MergeDataService)->StoreMergeData($request)
                ->all()
        );
    }

    public static function updateSubscription($request, $id)
    {
        $model = Service_letter_subscription::findOrFail($id);
        $model->fill($request->all());
        $model->save();

        return $model;
    }

    public static function toggleStatus($id)
    {
        $model = Service_letter_subscription::findOrFail($id);
        $model->state = $model->state ^ 1;
        $model->save();
        return $model;
    }
}
