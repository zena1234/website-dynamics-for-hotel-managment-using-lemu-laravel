<?php
namespace App\Models;

use App\Constants\MyModel;
use App\Requests\linksRequest;
use App\Services\MergeDataService;
use App\Services\FileService;
use App\Traits\UseState;
use Illuminate\Database\Eloquent\Model;

class Links  extends Model
{
    use UseState;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'name',
        'url',
        'logo',
        'description',
        'state'
    ];
    protected $hidden = ['deleted_at'];

    //Relationship
    public function category()
    {
        return $this->belongsTo(MyModel::CATEGORY)->select('id', 'name');
    }

    //Stores
    public static function storeLink($request)
    {
        $valid = (new linksRequest)->storeValidationRule($request);
        if (!$valid) 
            return $valid;
        $data['name']=$request->input('name');
        $data['url']=$request->input('url');
        $data['description']=$request->input('description');
        $data['id']=(new MergeDataService)->StoreMergeData($request)->id;
        $data['state']=(new MergeDataService)->StoreMergeData($request)->state;
        $name=time().$request->file('logo')->getClientOriginalName();
        $upload=(new FileService)->store($request,$name,'logo');
        $data['logo']=$name;
        return Links::create($data);
    }

    public static function changeLogo($request,$id){
        $name=time().$request->file('logo')->getClientOriginalName();
        $upload=(new FileService)->store($request,$name,'logo');
        $model=links::findOrFail($id); 
        $model->logo=$name;
        // dd($model);
        $model->save();
        return $model;
    }

    public static function updateLink($request, $id)
    {
        $valid = (new linksRequest)->updateValidationRule($request, $id);
        if (!$valid) return $valid;

        $model = links::findOrFail($id);
        $model->fill($request->all());
        $model->save();

        return $model;
    }

    public static function toggleStatus($id)
    {
        $model = links::findOrFail($id);
        $model->state = $model->state ^ 1;
        $model->save();
        return $model;
    }
}
