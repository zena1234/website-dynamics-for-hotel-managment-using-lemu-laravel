<?php
namespace App\Models;

use App\Services\MergeDataService;
use App\Traits\UseState;
use Illuminate\Database\Eloquent\Model;

class users extends Model
{
    use UseState;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'name',
        'floor_number',
        'bed_type',
        'category_id',
        'deleted_at',
        'state'
    ];
    protected $hidden = ['deleted_at'];

   public static function addUser($request){
        $data=new users();
        $data->name=$request->input('name');
        $data->id=(new MergeDataService)->StoreMergeData($request)->id;
        $data->save();
        return $data;
   }

    
}

