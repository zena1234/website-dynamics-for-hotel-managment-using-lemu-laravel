<?php
namespace App\Models;

use App\Constants\MyModel;
use App\Requests\RoomRequest;
// use App\Requests\FAQsRequest;
use App\Services\FileService;
use App\Services\MergeDataService;
use App\Traits\UseState;
use Illuminate\Database\Eloquent\Model;

class Gallery  extends Model
{
    use UseState;
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'service_id',
        'description',
        'featured_photo',
        'deleted_at',
        'state'
    ];
    protected $hidden = ['deleted_at'];

    //Relationship
    public function category()
    {
        return $this->belongsTo(MyModel::CATEGORY)->select('id', 'name');
    }

    //Stores
    public static function storeGallery($request)
    {
       
        // $valid = (new RoomRequest)->storeValidationRule($request);// I used roomRequest since both room request and testimonial need their name required
        // if (!$valid)
        //      return $valid;
        $data['service_id']=$request->input('service_id');
        $data['description']=$request->input('description');
        $data['id']=(new MergeDataService)->StoreMergeData($request)->id;
        $data['state']=(new MergeDataService)->StoreMergeData($request)->state;
        $name=time().$request->file('featured_photo')->getClientOriginalName();
        $upload=(new FileService)->store($request,$name,'featured_photo');
        $data['featured_photo']=$name;
        return Gallery::Create( $data);
    }

    public static function updateGallery($request, $id)
    {
        
        $model = Gallery::findOrFail($id);
        $model->fill($request->all());
        $model->save();

        return $model;
    }

    public static function toggleStatus($id)
    {
        $model = FAQs::findOrFail($id);
        $model->state = $model->state ^ 1;
        $model->save();
        return $model;
    }
}
