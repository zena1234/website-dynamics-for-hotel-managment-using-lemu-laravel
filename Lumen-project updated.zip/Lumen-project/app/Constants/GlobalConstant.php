<?php

class GlobalConstant {
    const PAGINATION_SIZE = 5;
    const CATEGORY_URI = "/hms/apis/v1/categories/photos/";
}
