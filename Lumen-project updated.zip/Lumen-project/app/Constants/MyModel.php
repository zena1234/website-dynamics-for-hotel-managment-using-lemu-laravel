<?php

namespace App\Constants;

class MyModel {
    const ROOM = "App\Models\Room";
    const Testimony="App\Models\Testimony";
    const FAQs="App\Models\FAQs";
    const CATEGORY = "App\Models\Category";
    const Links="App\Models\Links";
    const Users="App\Models\users";
    const services="App\Models\Services";
    const Gallery='App\Models\Gallery';
    const Subscribe="App\Models\service_letter_subscription";
    const News="App\Models\News";
}
