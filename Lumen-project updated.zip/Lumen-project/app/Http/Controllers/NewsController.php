<?php
namespace App\Http\Controllers;

use App\Constants\MyModel;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Controller;


class NewsController extends Controller{
    
    protected $_model = MyModel::News;
    protected $_defaultOrder = "updated_at";


    public function getAllNews(){
        return response()->json(
            $this->_model::active()->latest('published_at')->get(),
            Response::HTTP_OK
        );
    }
    public function showNews($id)
    {
        return response()->json(
            $this->_model::active()
                ->findOrFail($id),
            Response::HTTP_OK
        );
    }
    public function storeNews(Request $request)
    {
        if (!$request->all())
            return response()->json('bad_request', Response::HTTP_NOT_FOUND);

        return response()->json(
            $this->_model::storeNews($request),
            Response::HTTP_CREATED
        );
    }
    public function updateNews(Request $request,$id)
    {
        if (!$request->all())
            return response()->json('bad_request', Response::HTTP_NOT_FOUND);

        return response()->json(
            $this->_model::updateNews($request, $id),
            Response::HTTP_OK
        );
    }


    public function deleteNews($id)
    {
        $this->_model::listAll()
            ->findOrFail($id)
            ->delete();
        return response()->json('deleted', Response::HTTP_OK);
    }


    public function trash($id)
    {
        $this->_model::trashRecord($id);
        return response()->json('trashed', Response::HTTP_OK);
    }

    public function restore($id)
    {
        $this->_model::restoreRecord($id);
        return response()->json(
            $this->_model::active()->findOrFail($id),
            Response::HTTP_OK
        );
    }
    public function cleanTrash()
    {
        $this->_model::onlyTrashed()->delete();
        return response()->json('trash_emptied', Response::HTTP_OK);
    }
    public function changeFile(Request $request,$id){
        // dd($request);
        if (!$request->file('featured_photo'))
            return response()->json('bad_request', Response::HTTP_NOT_FOUND);

    return response()->json(
        $this->_model::changeFile($request, $id),
        Response::HTTP_OK
    );
    }
}