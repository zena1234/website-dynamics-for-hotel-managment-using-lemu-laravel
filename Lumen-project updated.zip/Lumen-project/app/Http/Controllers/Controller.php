<?php

namespace App\Http\Controllers;
use  App\Models\Room;
use Laravel\Lumen\Routing\Controller as BaseController;

class Controller extends BaseController
{
    public function home(){
        $users=User::all();
        return response()->json("Welcome to Backend development using Laravel/Lumen");
    }
 
}
