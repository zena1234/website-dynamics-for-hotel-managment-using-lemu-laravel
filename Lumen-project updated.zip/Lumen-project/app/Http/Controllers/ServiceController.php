<?php
namespace App\Http\Controllers;

namespace App\Http\Controllers;

use App\Constants\MyModel;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Controller;


class ServiceController extends Controller{
    protected $_model=MyModel::services;
    // protected $_model = MyModel::Users;
    protected $_defaultOrder = "updated_at";
    public function getServices(){
        $users=$this->_model::all();
        return response()->json($users);
    }
    public function storeService(Request $request){
        // dd($request);
        return response()->json(
            $this->_model::storeService($request),Response::HTTP_CREATED
        );
    }
}