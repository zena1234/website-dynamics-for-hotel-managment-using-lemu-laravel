<?php
namespace App\Http\Controllers;

use App\Constants\MyModel;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Controller;

class FAQsController extends Controller{
    protected $_model = MyModel::FAQs;
    protected $_defaultOrder = "updated_at";

    public function get(){
        return response()->json(
            $this->_model::active()
                ->oldest('question')
                ->get(),
            Response::HTTP_OK
        );
    }
    public function toggleStatus($id)
    {
        return response()->json(
            $this->_model::toggleStatus($id),
            Response::HTTP_OK
        );
    }

    public function addQuestion(Request $request){
        if (!$request->all())
        return response()->json('bad_request', Response::HTTP_NOT_FOUND);

    return response()->json(
        $this->_model::storeFAQ($request),
        Response::HTTP_CREATED
    );
    }public function update(Request $request,$id){
        if (!$request->all())
            return response()->json('bad_request', Response::HTTP_NOT_FOUND);

        return response()->json(
            $this->_model::updateFAQ($request, $id),
            Response::HTTP_OK
        );
    }
    public function trash($id)
    {
        $this->_model::trashRecord($id);
        return response()->json('Trashed', Response::HTTP_OK);
    }

    public function restore($id)
    {
        $this->_model::restoreRecord($id);
        return response()->json(
            $this->_model::active()->findOrFail($id),
            Response::HTTP_OK
        );
    }

    public function delete($id){
        $this->_model::listAll()
        ->findOrFail($id)
        ->delete();
    return response()->json('deleted', Response::HTTP_OK);
    }
    public function emptyTrash()
    {
        $this->_model::onlyTrashed()->delete();
        return response()->json('trash cleaned', Response::HTTP_OK);
    }
    
}