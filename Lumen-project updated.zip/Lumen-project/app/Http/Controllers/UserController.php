<?php 
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\Users;
use App\Constants\MyModel;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class UserController extends Controller
{
    protected $_model = MyModel::Users;
    protected $_defaultOrder = "updated_at";
    public function getUsers(){
        $users=Users::all();
        return response()->json($users);
    }
    public function addUser(Request $request){
        return response()->json(
            $this->_model::addUser($request),
            Response::HTTP_CREATED
        );
    }
  
}