<?php
namespace App\Http\Controllers;

use App\Constants\MyModel;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Controller;

class LinksController extends Controller{
    protected $_model = MyModel::Links;
    protected $_defaultOrder = "updated_at";

    public function getLinks(){
        return response()->json(
            $this->_model::active()
                ->oldest('name')
                ->get(),
            Response::HTTP_OK
        );
    }
    public function toggleStatus($id)
    {
        return response()->json(
            $this->_model::toggleStatus($id),
            Response::HTTP_OK
        );
    }

    public function addLink(Request $request){
        // dd($request);
        if (!$request->all())
        return response()->json('bad_request', Response::HTTP_NOT_FOUND);

    return response()->json(
        $this->_model::storeLink($request),
        Response::HTTP_CREATED
    );
    }
    public function updateLink(Request $request,$id){  
        // dd($request);
        if (!$request->all())
            return response()->json('bad_request', Response::HTTP_NOT_FOUND);
        return response()->json(
            $this->_model::updateLink($request, $id),
            Response::HTTP_OK
        );
    }

    public function changeLogo(Request $request,$id){
        if(!$request->file('logo')){
             return response()->json("Bad Request",Response::HTTP_NOT_FOUND);
        }
        return response()->json(
            $this->_model::changeLogo($request, $id),
            Response::HTTP_OK
        );
    }

    public function trashLink($id)
    {
        $this->_model::trashRecord($id);
        return response()->json('Trashed', Response::HTTP_OK);
    }

    public function restoreLink($id)
    {
        $this->_model::restoreRecord($id);
        return response()->json(
            $this->_model::active()->findOrFail($id),
            Response::HTTP_OK
        );
    }

    public function deleteLink($id){
        $this->_model::listAll()
        ->findOrFail($id)
        ->delete();
    return response()->json('deleted', Response::HTTP_OK);
    }
    public function cleanTrash()
    {
        $this->_model::onlyTrashed()->delete();
        return response()->json('trash cleaned', Response::HTTP_OK);
    }
    
}