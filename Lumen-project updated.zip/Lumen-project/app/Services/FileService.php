<?php

namespace App\Services;

use Illuminate\Support\Facades\File;

class FileService {

    // public static function storeFile($request, $pathName)
    // {
    //     if (!$request->attachment) {
    //         return null;
    //     }
    //     $filePath = storage_path().$pathName;
    //     $fileName = date_format(date_create(), 'YmdHisu').mt_rand(1000, 9999);
    //     $request->attachment->move($filePath, $fileName);
    // }
    public function store($request,$fileName,$type){
        if($request->file($type)){
            $destination='./images';
            $moved=$request->file($type)->move($destination,$fileName);
            return 1;
        }
    }
    public static function getFileUrl($models, $uri)
    {
        $fileBaseUrl = url('/').$uri;
        foreach ($models as $model) {
            $model->attachment = isset($model->featured_photo) ? $fileBaseUrl.$models->featured_photo : null;
        }
        return $models;
    }
     
    public static function downloadFile($path, $fileName)
    {
        $path = storage_path().$path.$fileName;
        $file = File::get($path);
        $type = File::mimeType($path);

        return response($file)->header('Content-Type', $type);
        // return response($file, 'Content-Type', $type);
    }
}
