<?php

namespace App\Requests;

use App\Http\Controllers\Controller;

class FAQsRequest extends Controller {
    public function storeValidationRule($request)
    {
        return $this->validate($request, [
            'question' => 'required|unique:faqs,id',
            'answer' => 'required|unique:faqs,id'
        ]);
    }
    public function updateValidationRule($request,$id)
    {
        return $this->validate($request, [
            'question' => 'required|unique:faqs,id'.','.$id,
            'answer' => 'required|unique:faqs,id'.','.$id

        ]);
    }
    
}