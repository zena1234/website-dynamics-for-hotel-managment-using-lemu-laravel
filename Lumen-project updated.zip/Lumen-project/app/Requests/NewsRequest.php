<?php

namespace App\Requests;

use App\Http\Controllers\Controller;

class NewsRequest extends Controller {
    public function storeValidationRule($request)
    {
        return $this->validate($request, [
            'body' => 'required:links,id',
            'id' => 'required|unique:links,id'
        ]);
    }
    public function updateValidationRule($request,$id)
    {
        return $this->validate($request, [
            'id' => 'required|unique:links,id'

        ]);
    }
    
}