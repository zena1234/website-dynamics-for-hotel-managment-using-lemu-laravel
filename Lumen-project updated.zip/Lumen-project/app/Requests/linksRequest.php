<?php

namespace App\Requests;

use App\Http\Controllers\Controller;

class LinksRequest extends Controller {
    public function storeValidationRule($request)
    {
        return $this->validate($request, [
            'name' => 'required:links,id',
            'url' => 'required|unique:links,id'
        ]);
    }
    public function updateValidationRule($request,$id)
    {
        return $this->validate($request, [
            'name' => 'required:links,id'.','.$id,
            'url' => 'required|unique:links,id'.','.$id

        ]);
    }
    
}