<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Testimony extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('testimonies', function (Blueprint $table) {
            $table->string('id', 36)->primary();
            $table->string('name');
            $table->string('position');
            $table->string('quoted_text')->nullable();
            $table->string('featured_photo')->nullable();
            $table->datetime('deleted_at')->nullable();
            $table->integer('state')->default(1);
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('testimonies');//
    }
}