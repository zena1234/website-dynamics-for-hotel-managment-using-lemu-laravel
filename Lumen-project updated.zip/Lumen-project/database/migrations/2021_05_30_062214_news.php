<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

class News extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users',function(Blueprint $table){
            $table->String('id',36)->primary();
            $table->string('name');
            $table->timestamps();
        });
        Schema::create('news',function(Blueprint $table){
            $table->string('id',36)->primary();
            $table->String('user_id');
            $table->string('category_id');
            $table->string('title');
            $table->string('summary');
            $table->string('body');
            $table->string('featured_photo');
            $table->datetime('published_at')->default(Carbon::now())->nullable();
            $table->datetime('unpublished_at')->nullable();
            $table->String('published_by')->nullable();
            $table->String('unpublished_by')->nullable();
            $table->datetime('deleted_at')->nullable();
            $table->Integer('state')->default(1);
            $table->timestamps();
            $table->foreign('user_id')->references('id')->on('users');
            $table->foreign('category_id')->references('id')->on('categories');
            $table->foreign('published_by')->references('id')->on('users')->nullable();
            $table->foreign('unpublished_by')->references('id')->on('users')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('news');
    }
}