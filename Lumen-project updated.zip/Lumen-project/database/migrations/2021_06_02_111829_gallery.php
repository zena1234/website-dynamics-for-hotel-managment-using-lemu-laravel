<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Gallery extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('galleries',function(Blueprint $table){
            $table->string('id',36)->primary();
            $table->string('service_id')->nullable();
            $table->string('description');
            $table->string('featured_photo');
            $table->datetime('deleted_at')->nullable();
            $table->integer('state')->default(1);
            $table->timestamps();
            $table->foreign('service_id')->references('service_id')->on('services');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('galleries');
    }
}

