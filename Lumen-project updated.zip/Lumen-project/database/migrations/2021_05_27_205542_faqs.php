<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Faqs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('faqs',function(Blueprint $table){
            
            $table->string('id',36)->primary();
            $table->string('question');
            $table->string('answer');
            $table->string('detailed_answer')->nullable();
            $table->dateTime('deleted_at')->nullable();
            $table->integer('state')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        
        Schema::dropIfExists('faqs');
    }
}
