<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/
#DONE
$router->group(['prefix' => 'hms/apis/v1'], function () use ($router) {
     $router->group(['prefix'=>'testimonials'],function() use ($router){
         $router->get('',['uses'=>'TestimonialController@index']);
         $router->post('add',['uses'=>'TestimonialController@store']);
         $router->delete('delete/{id}',['uses'=>'TestimonialController@delete']);
         $router->put('update/{id}',['uses'=>'TestimonialController@update']);
         $router->delete('trash', ['uses' => 'TestimonialController@emptyTrash']);
         $router->delete('{id}', ['uses' => 'TestimonialController@trash']);
         $router->post('change_featured_photo/{id}',['uses'=>'TestimonialController@changeFeaturedPhoto']);
         $router->delete('{id}/restore', ['uses' => 'TestimonialController@restore']);
       
       
     });
     $router->group(['prefix'=>'services'],function() use($router){
         $router->get('/','ServiceController@getServices');
         $router->post('/','ServiceController@storeService');
     });

     $router->group(['prefix'=>'/users'],function()use($router){
         $router->get('/','UserController@getUsers');
         $router->post('/','UserController@addUser');
     });

#DONE
     $router->group(['prefix'=>'/news'],function() use($router){
        $router->get('/',"NewsController@getAllNews");
        $router->get('/{id}','NewsController@showNews');
        $router->post('/','NewsController@storeNews');
        $router->post('/edit/{id}','NewsController@updateNews');
        $router->post('/delete/{id}','NewsController@deleteNews');
        $router->delete('/trash/{id}','NewsController@trash');
        $router->delete('/restore/{id}','NewsController@restore');
        #unchecked-1
        $router->delete('/cleanTrash','NewsController@cleanTrash');
        $router->get('/file/{filename}','NewsController@getFile');
        $router->post('/changeFile/{id}','NewsController@changeFile');
     });


#DONE

     $router->group(['prefix'=>'links'],function() use($router){
        $router->get('/',['uses'=>'LinksController@getLinks']);
        $router->post('/addLink',['uses'=>'LinksController@addLink']);
        $router->post('/editLink/{id}',['uses'=>'LinksController@updateLink']);
        $router->delete('/delete/{id}',['uses'=>'LinksController@deleteLink']);
        $router->delete('/trash/{id}',['uses'=>'LinksController@trashLink']);
        $router->delete('/restore/{id}',['uses'=>'LinksController@restoreLink']);
        $router->delete('/cleanTrash',['uses'=>'LinksController@cleanTrash']);
        $router->post('{id}/toggle-status', ['uses' => 'LinksController@toggleStatus']);
        $router->post('/changeLogo/{id}',['uses'=>'LinksController@changeLogo']);
     });

#DONE


    $router->group(['prefix'=>'FAQs'],function() use ($router){
        $router->get('/',['uses'=>'FAQsController@get']);
        $router->post('addQuestion',['uses'=>'FAQsController@addQuestion']);
        $router->delete('/deleteQuestion/{id}',['uses'=>'FAQsController@delete']);
        $router->post('/editQuestion/{id}',['uses'=>'FAQsController@update']);
        $router->delete('/trashQuestion/{id}',['uses'=>'FAQsController@trash']);
        $router->delete('/cleanTrash',['uses'=>'FAQsController@emptyTrash']);
        $router->delete('/restore/{id}', ['uses' => 'FAQsController@restore']);
        $router->post('{id}/toggle-status', ['uses' => 'FAQsController@toggleStatus']);


    });
#DONE
    $router->group(['prefix' => 'rooms'], function () use ($router) { //Duplicate this uri for other nanoservices.
        $router->get('', [  'uses' => 'RoomController@index']);
        $router->get('all', ['uses' => 'RoomController@all']);
        $router->get('{id}', ['uses' => 'RoomController@show']);
        //unchecked
        $router->get('where/{attribute}/{value}', ['uses' => 'RoomController@query']);

        $router->post('create', ['uses' => 'RoomController@store']);
        $router->post('{id}', ['uses' => 'RoomController@update']);
        //unchecked
        $router->put('{id}/toggle-status', ['uses' => 'RoomController@toggleStatus']);
        $router->delete('empty-trash', ['uses' => 'RoomController@emptyTrash']);
        $router->delete('{id}', ['uses' => 'RoomController@trash']);
        $router->delete('{id}/restore', ['uses' => 'RoomController@restore']);
        $router->delete('{id}/delete', ['uses' => 'RoomController@delete']);
    });
    $router->group(['prefix'=>'gallery'],function()use($router){
        $router->get('/','GalleryController@getAll');
        $router->post('/','GalleryController@addGallery');
        $router->post('/update/{id}','GalleryController@update');
        $router->delete('delete/{id}','GalleryController@delete');
        $router->delete('/trash/{id}','GalleryController@trash');
        $router->delete('/cleanTrash','GalleryController@emptyTrash');
        $router->delete('/restore/{id}','GalleryController@restore');
    });

    $router->group(['prefix'=>'subscription'],function()use($router){
        $router->get('/','SubscriptionController@get');
        $router->post('/','SubscriptionController@store');
        $router->post('/update/{id}','SubscriptionController@update');
        $router->delete('delete/{id}','SubscriptionController@delete');
        $router->delete('/trash/{id}','SubscriptionController@trash');
        $router->delete('/cleanTrash','SubscriptionController@emptyTrash');
        $router->delete('/restore/{id}','SubscriptionController@restore');
    });
});



// $router->post('/create','RoomController@store');
// $router->get('/home','UserController@Home');
// $router->post('/update/{id}',"UserController@update");
// $router->post('/delete/{id}',"UserController@delete");
// $router->get('/','RoomController@index' );
